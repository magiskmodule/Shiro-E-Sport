#!/system/bin/sh
MODDIR=${0%/*}
write() {
	[[ ! -f "$1" ]] && return 1
		chmod +w "$1" 2> /dev/null

    if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}
echo "com.miHoYo., com.activision., UnityMain, libunity.so, libil2cpp.so, libfb.so" > /proc/sys/kernel/sched_lib_name
echo "240" > /proc/sys/kernel/sched_lib_mask_force
echo "3" > /proc/sys/vm/drop_caches
echo "8" > /sys/block/zram0/max_comp_streams
echo "20" > /proc/sys/vm/dirty_background_ratio
echo "1000" > /proc/sys/vm/dirty_expire_centisecs
echo "0" > /proc/sys/vm/page-cluster
echo "10" > /proc/sys/vm/dirty_ratio
echo "0" > /proc/sys/vm/laptop_mode
echo "1" > /proc/sys/vm/block_dump
echo "0" > /proc/sys/vm/compact_memory
echo "5000" > /proc/sys/vm/dirty_writeback_centisecs
echo "1" > /proc/sys/vm/oom_dump_tasks
echo "0" > /proc/sys/vm/oom_kill_allocating_task
echo "60" > /proc/sys/vm/stat_interval
echo "0" > /proc/sys/vm/panic_on_oom
echo "20" > /proc/sys/vm/swappiness
echo "50" > /proc/sys/vm/vfs_cache_pressure
echo "80" > /proc/sys/vm/overcommit_ratio
echo "10240" > /proc/sys/vm/extra_free_kbytes
echo "64" > /proc/sys/kernel/random/read_wakeup_threshold
echo "128" > /proc/sys/kernel/random/write_wakeup_threshold

# Dev Stune Boost
# Fast Sensivity in Game
echo "20" > /dev/stune/background/schedtune.boost
echo "0" > /dev/stune/background/schedtune.prefer_idle
echo "0" > /dev/stune/background/schedtune.colocate
echo "0" > /dev/stune/background/schedtune.sched_boost_enabled

echo "20" > /dev/stune/foreground/schedtune.boost
echo "0" > /dev/stune/foreground/schedtune.prefer_idle
echo "0" > /dev/stune/foreground/schedtune.colocate
echo "0" > /dev/stune/foreground/schedtune.sched_boost_enabled

echo "20" > /dev/stune/rt/schedtune.boost
echo "0" > /dev/stune/rt/schedtune.prefer_idle
echo "0" > /dev/stune/rt/schedtune.colocate
echo "0" > /dev/stune/rt/schedtune.sched_boost_enabled

echo "20" > /dev/stune/top-app/schedtune.boost
echo "0" > /dev/stune/top-app/schedtune.prefer_idle
echo "0" > /dev/stune/top-app/schedtune.colocate
echo "0" > /dev/stune/top-app/schedtune.sched_boost_enabled

echo "20" > /dev/stune/schedtune.boost
echo "0" > /dev/stune/schedtune.prefer_idle
echo "0" > /dev/stune/schedtune.colocate
echo "0" > /dev/stune/schedtune.sched_boost_enabled

# Mengatur minfree dalam kernel Android
echo "5120,6144,7168,8192,9216,10240" > /sys/module/lowmemorykiller/parameters/minfree

# Mengatur semua CPU ke mode kinerja tinggi dengan pengaturan tambahan.
echo "0" > /sys/devices/system/cpu/isolated
echo "0" > /sys/devices/system/cpu/offline
echo "0" > /sys/devices/system/cpu/uevent
echo "1" > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable
echo "1" > /sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable
echo "0" > /sys/devices/system/cpu/cpufreq/performance/above_hispeed_delay
echo "1" > /sys/devices/system/cpu/cpufreq/performance/boost
echo "100" > /sys/devices/system/cpu/cpufreq/performance/go_hispeed_load
echo "1" > /sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis
echo "1" > /sys/devices/system/cpu/cpufreq/performance/align_windows
echo "performance" > /sys/kernel/gpu/gpu_governor
echo "performance" > /sys/class/kgsl/kgsl-3d0/devfreq/governor
echo "0" > /sys/module/adreno_idler/parameters/adreno_idler_active
echo "8" > /sys/module/lazyplug/parameters/nr_possible_cores
echo "1" > /sys/module/msm_performance/parameters/touchboost
echo "4-7" > /dev/cpuset/foreground/boost/cpus
echo "0-3,4-7" > /dev/cpuset/foreground/cpus
echo "0-7" > /dev/cpuset/top-app/cpus
chmod 644 /sys/module/workqueue/parameters/power_efficient
echo "Y" > /sys/module/workqueue/parameters/power_efficient
echo "100" > /sys/module/cpu_boost/parameters/input_boost_ms

# Disable VSync
chmod 666 /sys/module/sync/parameters/fsync_enable
chown root /sys/module/sync/parameters/fsync_enable
echo "N" > /sys/module/sync/parameters/fsync_enable

# Menonaktifkan override status termal
su -c "cmd thermalservice override-status 0"

# Mengaktifkan mode kinerja tetap
su -c "cmd power set-fixed-performance-mode-enabled true"

#PPM (Mediatek)
echo "1" > /proc/ppm/enabled
echo "0 0" > /proc/ppm/policy_status
echo "1 1" > /proc/ppm/policy_status
echo "2 0" > /proc/ppm/policy_status
echo "3 0" > /proc/ppm/policy_status
echo "4 0" > /proc/ppm/policy_status
echo "5 0" > /proc/ppm/policy_status
echo "6 1" > /proc/ppm/policy_status
echo "7 0" > /proc/ppm/policy_status
echo "8 0" > /proc/ppm/policy_status
echo "9 0" > /proc/ppm/policy_status

# Menghentikan berbagai layanan
stop logd
stop perfd
stop tcpdump
stop cnss_diag
stop statsd
stop traced
stop idd-logreader
stop idd-logreadermain
stop vendor.perfservice
stop miuibooster
stop system_perf_init

# GPU
setprop init.svc.gpu stopped
setprop init.svc.gpu-1-0 stopped

# Device Google Pixel
setprop persist.sys.pixelprops.games 0
setprop persist.sys.pixelprops.gphotos 1

# disable gms
su -c "pm disable com.google.android.gms/.chimera.GmsIntentOperationService"

# Adjust block device queue settings
for queue in /sys/block/mmcblk*/queue; do
    echo "$queue/scheduler" "none"
    echo "$queue/add_random" "0"
    echo "$queue/iostats" "0"
    echo "$queue/read_ahead_kb" "256"
    echo "$queue/nr_requests" "128"
  done

for block in mmcblk0rpmb mmcblk1 loop0 loop1 loop2 loop3 loop4 loop5 loop6 loop7 loop8 loop9 loop10 loop11 loop12 loop13 loop14 loop15 fs/f2fs_dev/mmcblk0p79; do
    echo "0" > "/sys/block/$block/queue/iostats"
done

# Disabe Kernel Panic
files="/proc/sys/kernel/panic /proc/sys/kernel/panic_on_oops /proc/sys/kernel/panic_on_rcu_stall /proc/sys/kernel/panic_on_warn /sys/module/kernel/parameters/panic /sys/module/kernel/parameters/panic_on_warn /sys/module/kernel/parameters/panic_on_oops /sys/vm/panic_on_oom"
for file in $files; do echo "0" > "$file"; done

# Konfigurasi log kernel
echo "0 0 0 0" > /proc/sys/kernel/printk 
echo "off" > /proc/sys/kernel/printk_devkmsg
echo "Y" > /sys/module/printk/parameters/console_suspend
echo "N" > /sys/module/printk/parameters/cpu
echo "Y" > /sys/module/printk/parameters/ignore_loglevel
echo "N" > /sys/module/printk/parameters/pid
echo "N" > /sys/module/printk/parameters/time
echo "0" > /sys/kernel/printk_mode/printk_mode

# Disables GPU debugging
base_path="/sys/kernel/debug/kgsl/kgsl-3d0"
for log in log_level_cmd log_level_ctxt log_level_drv log_level_mem log_level_pwr; do
  echo "0" > "$base_path/$log"
done

# Gpu Tweaks
echo "0" > /sys/class/kgsl/kgsl-3d0/throttling
echo "1" > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
echo "1" > /sys/class/kgsl/kgsl-3d0/force_clk_on
echo "1" > /sys/class/kgsl/kgsl-3d0/force_bus_on
echo "1" > /sys/class/kgsl/kgsl-3d0/force_rail_on
echo "1" > /sys/class/kgsl/kgsl-3d0/force_no_nap

# I/O
for device in mmcblk0 mmcblk1 sda sdb sdc sdd sde sdf; do
    echo "cfq" > /sys/block/$device/queue/scheduler
    echo "1024" > /sys/block/$device/queue/read_ahead_kb
    echo "0" > /sys/block/$device/queue/rotational
    echo "0" > /sys/block/$device/queue/iostats
    echo "0" > /sys/block/$device/queue/add_random
    echo "1" > /sys/block/$device/queue/rq_affinity
    echo "0" > /sys/block/$device/queue/nomerges
    echo "1024" > /sys/block/$device/queue/nr_requests
done
 
# Adjust GPU power and performance settings
echo "0" > /sys/class/kgsl/kgsl-3d0/thermal_pwrlevel
echo "0" > /sys/class/kgsl/kgsl-3d0/max_pwrlevel
echo "0" > /sys/class/kgsl/kgsl-3d0/perfcounter
echo "1" > /sys/class/kgsl/kgsl-3d0/bus_split

# Adreno Boost
echo "0" > /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost
echo "0" > /sys/module/msm_performance/parameters/touchboost

# Disable access to CPU and core information
chmod 000 /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu1/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu2/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu3/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu5/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu6/cpufreq/cpuinfo_max_freq
chmod 000 /sys/devices/system/cpu/cpu7/cpufreq/cpuinfo_max_freq

chmod 000 /sys/devices/system/cpu/cpu0/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu1/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu2/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu3/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu4/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu5/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu6/cpu_capacity
chmod 000 /sys/devices/system/cpu/cpu7/cpu_capacity

chmod 000 /sys/devices/system/cpu/cpu0/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu1/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu2/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu3/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu4/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu5/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu6/topology/physical_package_id
chmod 000 /sys/devices/system/cpu/cpu7/topology/physical_package_id

# CPU core control
echo "0" > /sys/devices/system/cpu/cpu0/core_ctl/enable
echo "1" > /sys/devices/system/cpu/cpu0/core_ctl/min_cpus
echo "4" > /sys/devices/system/cpu/cpu0/core_ctl/max_cpus
echo "100" > /sys/devices/system/cpu/cpu0/core_ctl/offline_delay_ms
echo "0" > /sys/devices/system/cpu/cpu0/core_ctl/is_big_cluster
echo "1" > /sys/devices/system/cpu/cpu4/core_ctl/enable
echo "2" > /sys/devices/system/cpu/cpu4/core_ctl/min_cpus
echo "4" > /sys/devices/system/cpu/cpu4/core_ctl/max_cpus
echo "70" > /sys/devices/system/cpu/cpu4/core_ctl/busy_up_thres
echo "60" > /sys/devices/system/cpu/cpu4/core_ctl/busy_down_thres
echo "100" > /sys/devices/system/cpu/cpu4/core_ctl/offline_delay_ms
echo "1" > /sys/devices/system/cpu/cpu4/core_ctl/is_big_cluster
echo "4" > /sys/devices/system/cpu/cpu4/core_ctl/task_thres

# LPM Turn off to go to sleep
echo "N" > /sys/module/lpm_levels/parameters/sleep_disabled
echo "N" > /sys/module/lpm_levels/parameters/lpm_prediction
echo "N" > /sys/module/lpm_levels/parameters/lpm_ipi_prediction
for i in $(seq 0 15); do
  echo "1024" > "/sys/block/ram$i/queue/read_ahead_kb"
done
echo "1024" > /sys/block/vnswap0/queue/read_ahead_kb

# Perf Event Tweak
echo "400000" > /proc/sys/kernel/perf_event_max_sample_rate
echo "100" > /proc/sys/kernel/perf_cpu_time_max_percent
echo "128" > /proc/sys/kernel/perf_event_max_contexts_per_stack
echo "4000" > /proc/sys/kernel/perf_event_mlock_kb
echo "-1" > /proc/sys/kernel/perf_event_paranoid
exit 0