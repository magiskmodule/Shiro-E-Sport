MODDIR=${0%/*}

cmd wifi force-low-latency-mode enabled

iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 8.8.8.8:53
iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 8.8.4.4:53
iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 8.8.8.8:53
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 8.8.4.4:53

echo '0' > /proc/sys/net/ipv4/ip_no_pmtu_disc;
echo '0' > /proc/sys/net/ipv4/tcp_ecn;
echo '0' > /proc/sys/net/ipv4/tcp_timestamps;
echo '1' > /proc/sys/net/ipv4/route.flush;
echo '1' > /proc/sys/net/ipv4/tcp_rfc1337;
echo '1' > /proc/sys/net/ipv4/tcp_tw_reuse;
echo '1' > /proc/sys/net/ipv4/tcp_sack;
echo '1' > /proc/sys/net/ipv4/tcp_fack;
echo '1' > /proc/sys/net/ipv4/tcp_tw_recycle;
echo '1' > /proc/sys/net/ipv4/tcp_window_scaling;
echo '6' > /proc/sys/net/ipv4/tcp_probe_threshold;
echo '10' > /proc/sys/net/ipv4/tcp_keepalive_probes;
echo '30' > /proc/sys/net/ipv4/tcp_keepalive_intvl;
echo '5' > /proc/sys/net/ipv4/tcp_fin_timeout;
echo '80' > /proc/sys/net/ipv4/tcp_pacing_ca_ratio;
echo '150' > /proc/sys/net/ipv4/tcp_pacing_ss_ratio;
echo '400' > /proc/sys/net/ipv4/tcp_probe_interval;
echo "404480" > /proc/sys/net/core/wmem_max;
echo "404480" > /proc/sys/net/core/rmem_max;
echo "256960" > /proc/sys/net/core/rmem_default;
echo "256960" > /proc/sys/net/core/wmem_default;
echo "4096,16384,404480" > /proc/sys/net/ipv4/tcp_wmem;
echo "4096,87380,404480" > /proc/sys/net/ipv4/tcp_rmem; 
echo '404480 404480 404480' > /proc/sys/net/ipv4/tcp_mem;
echo 'Y' > /sys/module/module/parameters/lock_wlanmodule;
chown wifi wifi /sys/module/wlan/parameters/fwpath;
cat /proc/sys/net/ipv4/tcp_allowed_congestion_control;
echo 'bbr westwood cubic reno' > /proc/sys/net/ipv4/tcp_allowed_congestion_control;
cat /proc/sys/net/ipv4/tcp_available_congestion_control;
echo 'bbr westwood cubic reno bic cdg dctcp hybla htcp vegas veno lp yeah illinois' > /proc/sys/net/ipv4/tcp_available_congestion_control;
cat /proc/sys/net/ipv4/tcp_congestion_control;
sudo sysctl -w net.ipv4.tcp_congestion_control=bbr
sudo sysctl -w net/ipv4/tcp_congestion_control=bbr
echo 'bbr' > /proc/sys/net/ipv4/tcp_congestion_control;
restorecon -R /proc/sys/net/ipv4/tcp_congestion_control;

#Fstrim
fstrim /data;
fstrim /system;
fstrim /cache;
fstrim /vendor;
fstrim /product;