REPLACE="
TMPDIR=$NVBASE/low_screen_touch_delay
[ -d $TMPDIR ] && rm -rf $TMPDIR
mkdir -p $TMPDIR

unzip -o "$ZIPFILE" module.prop -d $TMPDIR >&2
chmod -R 777 $TMPDIR

MODID=`grep_prop id $TMPDIR/module.prop`
MODAUTHOR=`grep_prop author $TMPDIR/module.prop`
MODNAME=`grep_prop name $TMPDIR/module.prop`
MODVERSION=`grep_prop version $TMPDIR/module.prop`
rm -rf $TMPDIR

vendorprop_systemlib64() {
mkdir -p $NVBASE/modules_update/$MODID/system/
mkdir -p $NVBASE/modules_update/$MODID/system/vendor/
mkdir -p $NVBASE/modules_update/$MODID/system/lib64
cp /vendor/build.prop $NVBASE/modules_update/$MODID/system/vendor/
cp /system/etc/permissions/privapp-permissions-platform.xml$NVBASE/modules_update/$MODID/system/etc/permissions
sleep 1
sed -i "/offset/d" $NVBASE/modules_update/$MODID/system/vendor/build.prop
sed -i "/keystore/d" $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
echo "" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.use_phase_offsets_as_durations=1" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.late.sf.duration=10500000" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.late.app.duration=16600000" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.treat_170m_as_sRGB=1" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.earlyGl.app.duration=16600000" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.frame_rate_multiple_threshold=120" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2

}
rm -rf $TMPDIR
  set_perm_recursive $MODPATH 0 0 0777 0777